import api.AdminResource;
import api.HotelResource;
import model.*;
import model.Customer;
import model.IRoom;
import model.Room;
import model.RoomType;

import java.util.Collection;
import java.util.Scanner;
public class AdminMenu {

    public static void startActions() {
        System.out.println("Admin Menu");
        System.out.println("===================");
        System.out.println("1. See all Customers");
        System.out.println("2. See all Rooms");
        System.out.println("3. See all Reservations");
        System.out.println("4. Add a Room");
        System.out.println("5. Back to Main Menu");
        System.out.println("=====================");
        System.out.println("Please select a number for the menu option");
    }

    public static boolean executeSelection(Scanner scanner, Integer select) {
        boolean keepAdminRunning = true;
        switch (select) {
            case 1 -> getAllCustomers();
            case 2 -> getAllRooms();
            case 3 -> getAllReservations();
            case 4 -> addRooms(scanner);
            case 5 -> { new MainMenu(); MainMenu.startActions();}
        }
        return keepAdminRunning;
    }


    private static void getAllCustomers() {
        Collection<Customer> allCustomers = AdminResource.getAllCustomers();
        if (allCustomers.isEmpty()) {
            System.out.println("There are no customers");
        } else {
            for (Customer customer : allCustomers) {
                System.out.println(customer.toString());
            }
        }
        System.out.println();
    }

    private static void getAllRooms() {
        Collection<IRoom> allRooms = AdminResource.getAllRooms();
        if (allRooms.isEmpty()) {
            System.out.println("There are no rooms");
        } else {
            for (IRoom room : allRooms) {
                System.out.println(room.toString());
            }
        }
        System.out.println();
    }

    private static void getAllReservations() {
        Collection<Reservation> allReservations = AdminResource.getAllReservations();
        if (allReservations.isEmpty()) {
            System.out.println("There are no reservations");
        } else {
            for (Reservation reservation : allReservations) {
                System.out.println(reservation.toString());
            }
        }
        System.out.println();
    }

    private static void addRooms(Scanner scanner) {
        boolean keepAddingRooms;
        do {
            addRoom(scanner);
            System.out.println("Do you want to add another room? Please enter (y/n)");
            String response = scanner.nextLine();
            keepAddingRooms = response.equalsIgnoreCase("y");
        } while (keepAddingRooms);
    }

    private static void addRoom(Scanner scanner) {
        String roomNumber = null;
        boolean validRoomNumber = false;
        while (!validRoomNumber) {
            System.out.println("Please enter the room number. ");
            roomNumber = scanner.nextLine();
            IRoom roomExists = HotelResource.getRoom(roomNumber);
            if (roomExists == null) {
                validRoomNumber = true;
            } else {
                System.out.println("That room already exists. Please enter y to update it, or enter another room number. ");
                String response  = scanner.nextLine();
                if (response.equalsIgnoreCase("y")){
                    validRoomNumber = true;
                }
            }
        }

        double price = 0.0;
        boolean validPrice = false;
        while (!validPrice) {
            try {
                System.out.println("Please enter the price for the room per night.");
                price = Double.parseDouble(scanner.nextLine());
                if (price < 0) {
                    System.out.println("The price must be greater or equal than 0.0");
                } else {
                    validPrice = true;
                }
            } catch (Exception ex) {
                System.out.println("Please enter a valid price");
            }
        }

        RoomType roomType = null;
        boolean validRoomType = false;
        while (!validRoomType) {
            try {
                System.out.println("Enter room type (1 for single bed, 2 for double bed): ");
                roomType = RoomType.valuerNumberOfBeds(Integer.parseInt(scanner.nextLine()));
                if (roomType == null) {
                    System.out.println("Please enter a valid room type");
                } else {
                    validRoomType = true;
                }
            } catch (Exception ex) {
                System.out.println("Please enter a valid room type");
            }
        }

        Room newRoom = new Room(roomNumber, price, roomType);
        AdminResource.addRoom(newRoom);
    }

}

//https://knowledge.udacity.com/questions/721101
//https://knowledge.udacity.com/questions/617535
