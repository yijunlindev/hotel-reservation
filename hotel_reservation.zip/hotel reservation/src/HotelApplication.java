import java.util.Scanner;

public class HotelApplication {

    public static void main(String[] args) {
        boolean keepRunning = true;
        try (Scanner scanner = new Scanner(System.in)) {
                while (keepRunning) {
                    try {
                        MainMenu.startActions();
                        int selection = Integer.parseInt(scanner.nextLine());
                        keepRunning = MainMenu.executeSelection(scanner, selection);
                    } catch (Exception ex) {
                        System.out.println("Please enter a valid number 1 to 5. Please try again.\n");
                    }
                }
            } catch (Exception ex) {
                System.out.println("\nError - Exiting program...\n");
            }
        }

    }