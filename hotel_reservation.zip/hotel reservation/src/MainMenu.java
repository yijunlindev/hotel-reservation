
import api.HotelResource;
import model.Customer;
import model.IRoom;
import model.Reservation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Scanner;

public class MainMenu {
    public static void startActions() {

        System.out.println("Welcome to the Udacity Hotel Reservation Application");
        System.out.println("======================");
        System.out.println("1. Find and reserve a room");
        System.out.println("2. See my reservations");
        System.out.println("3. Create an account");
        System.out.println("4. Admin");
        System.out.println("5. Exit");
        System.out.println("=====================");
        System.out.println("Please select a number for the menu option");

    }

    private static void findAndReserveRoom(Scanner scanner) {

        Date checkInDate = getValidCheckInDate(scanner);
        Date checkOutDate = getValidCheckOutDate(scanner, checkInDate);
        Collection<IRoom> availableRooms = HotelResource.findRooms(checkInDate, checkOutDate);
        boolean goToBook = false;
        if (availableRooms.isEmpty()) {
            Date newCheckInDate = getGoodDate(checkInDate);
            Date newCheckOutDate = getGoodDate(checkOutDate);
            availableRooms = HotelResource.findRooms(newCheckInDate, newCheckOutDate);
        } else {
            System.out.println("There are available rooms for check-in on:" + checkInDate + " check-out on:" + checkOutDate);
        }
        if(!goToBook) {
            return;
        }
        Customer customer = getCustomerForReservation(scanner);
        if (customer == null) {
            System.out.println("Your account don't exist.");
            return;
        }
        IRoom room = getRoomForReservation(scanner, availableRooms);
        Reservation reservation = HotelResource.bookRoom(customer.getEmail(), room, checkInDate, checkOutDate);
        if (reservation == null) {
            System.out.println("Sorry for fail to book the room.");
        } else {
            System.out.println("Congratulation! You got a successful reservation!");
            System.out.println(reservation);
        }

    }

    private static Date getValidCheckInDate(Scanner scanner) {

        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        Date checkInDate = null;
        boolean validCheckInDate = false;
        while (!validCheckInDate) {
            System.out.println("Check-in date (mm/dd/yyyy): ");
            String inputCheckInDate = scanner.nextLine();
            try {
                checkInDate = formatter.parse(inputCheckInDate);
                Date today = new Date();
                if (checkInDate.before(today)) {
                    System.out.println("Please try again! The check-in date shouldn't be in the past");
                } else {
                    validCheckInDate = true;
                }
            } catch (ParseException ex) {
                System.out.println("Error! Please use mm/dd/yyyy format.");
            }
        }
        return checkInDate;

    }

    private static Date getValidCheckOutDate(Scanner scanner, Date checkInDate) {

        SimpleDateFormat DateFor = new SimpleDateFormat("MM/dd/yyyy");
        Date checkOutDate = null;
        boolean validCheckOutDate = false;
        while (!validCheckOutDate) {
            System.out.println("Check-out date (mm/dd/yyyy): ");
            String inputCheckOutDate = scanner.nextLine();
            try {
                checkOutDate = DateFor.parse(inputCheckOutDate);
                if (checkOutDate.before(checkInDate)) {
                    System.out.println("Please try again! The check-out date shouldn't be before the check-in date");
                } else {
                    validCheckOutDate = true;
                }
            } catch (ParseException ex) {
                System.out.println("Error! Please use mm/dd/yyyy format");
            }
        }
        return checkOutDate;
    }

    private static Date getGoodDate(Date date) {

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.getTime();

    }


    private static Customer getCustomerForReservation(Scanner scanner) {
        String email;
        boolean hasAccount = false;
        System.out.println("Do you have an account with us? If you have,please enter Y");
        String choice = scanner.nextLine();
        if (choice.equalsIgnoreCase("Y")) {
            hasAccount = true;
        }
        if (hasAccount) {
            System.out.println("Please enter email format: name@domain.com ");
            email = scanner.nextLine();
        } else {
            email = createAccount(scanner);
        }
        return HotelResource.getCustomer(email);
    }

    private static IRoom getRoomForReservation(Scanner scanner, Collection<IRoom> availableRooms) {
        IRoom room = null;
        String roomNumber;
        boolean validRoomNumber = false;
        while (!validRoomNumber) {
            System.out.println("What room would you like to reserve? Please enter the room number. ");
            roomNumber = scanner.nextLine();
            room = HotelResource.getRoom(roomNumber);
            if (!availableRooms.contains(room)) {
                System.out.println("The room is already reservation by others , please choose another room number.");
            } else {
                validRoomNumber = true;
            }
        }
        return room;

    }


    private static void getCustomerReservations(Scanner scanner) {

        System.out.println("Please enter email format: name@domain.com  ");
        String email = scanner.nextLine();
        Customer customer = HotelResource.getCustomer(email);
        if (customer == null) {
            System.out.println("We're sorry that no account exists.");
            return;
        }
        Collection<Reservation> reservations = HotelResource.getCustomerReservations(customer.getEmail());
        if (reservations.isEmpty()) {
            System.out.println("You don't have any reservations.Go to reservations now!");
            return;
        }
        for (Reservation reservation : reservations) {
            System.out.println(reservation.toString());
        }

    }


    private static String createAccount(Scanner scanner) {

        System.out.println("First name: ");
        String firstName = scanner.nextLine();
        System.out.println("Last name: ");
        String lastName = scanner.nextLine();
        String email = null;
        boolean validEmail = false;
        while (!validEmail) {
            try {
                System.out.println("Please enter email format: name@domain.com ");
                email = scanner.nextLine();
                HotelResource.createACustomer(email, firstName, lastName);
                System.out.println("The account is created successfully!\n");
                validEmail = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getLocalizedMessage());
            }
        }
        return email;

    }
    private static void runAdminMenu(Scanner scanner) {

        boolean keepAdminRunning = true;
        while (keepAdminRunning) {
            try {
                AdminMenu.startActions();
                int adminSelection = Integer.parseInt(scanner.nextLine());
                keepAdminRunning = AdminMenu.executeSelection(scanner, adminSelection);
            } catch (Exception ex) {
                System.out.println("Please enter a valid number 1 to 5. Please try again.\n");
            }
        }

    }

    public static boolean executeSelection(Scanner scanner, Integer select) {

        boolean keepRunning = true;
        switch (select) {
            case 1 -> findAndReserveRoom(scanner);
            case 2 -> getCustomerReservations(scanner);
            case 3 -> createAccount(scanner);
            case 4 -> runAdminMenu(scanner);
            case 5 -> keepRunning = false;
            default -> System.out.println("Please enter a valid number 1 to 5. Please try again.\n");
        }
        return keepRunning;
    }

}



//outline:https://knowledge.udacity.com/questions/577186
//reference: https://knowledge.udacity.com/questions/649254
//reference:https://knowledge.udacity.com/questions/655317
//reference::https://knowledge.udacity.com/questions/617535
