package api;

import model.Customer;
import model.IRoom;
import model.Reservation;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
public class AdminResource {

    public static Customer getCustomer(String email) {
        return CustomerService.getCustomer(email);
    }

    public static void addRoom(IRoom room) {
        ReservationService.addRoom(room);
    }

    @Contract(pure = true)
    public static @NotNull Collection<IRoom> getAllRooms() {
        return ReservationService.getAllRooms();
    }

    public static Collection<Customer> getAllCustomers() {
        return CustomerService.getAllCustomers();
    }

    public static @NotNull Collection<Reservation> getAllReservations() {
        return ReservationService.getAllReservations(); }


}

//outline :https://knowledge.udacity.com/questions/543175