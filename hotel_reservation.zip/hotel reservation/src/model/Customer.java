package model;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Customer {

    private final String firstName;
    private final String lastName;
    private final String email;

    String emailRegex = "^(.+)@(.+).(.+)$";
    Pattern pattern = Pattern.compile(emailRegex);
    Matcher matcher = pattern.matcher("jeff@example.com");

    public Customer(String firstName, String lastName, String email) {
        super();
        if (!pattern.matcher(email).matches()) {
            throw new IllegalArgumentException("Email must be a valid format, ex. jeff@example.com");
        }

        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getEmail() {

        return email;
    }

    @Override
    public String toString() {

        return "Name:" + firstName + " " +lastName + "Email:"+ email+ " ";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Customer customer)) return false;
        return firstName.equals(customer.firstName) && lastName.equals(customer.lastName) && email.equals(customer.email);
    }


    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, email);
    }
}

//Pattern source: https://knowledge.udacity.com/questions/599797
//Pattern source: https://knowledge.udacity.com/questions/536745
//hashCode source:https://knowledge.udacity.com/questions/536745