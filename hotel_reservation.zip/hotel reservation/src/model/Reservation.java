package model;

import java.util.Date;
import java.util.Objects;

public class Reservation {

   private Customer customer;
   private IRoom room;
   private Date checkInDate;
   private Date checkOutDate;

   public Reservation(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        super();
        this.customer = customer;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    public Customer getCustomer() {
        return customer;
    }

   public void setCustomer(Customer customer) {
       this.customer = customer;
   }
    public IRoom getRoom() {
        return room;
    }

    public void setRoom(IRoom room) {
        this.room = room;
    }

    public Date getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }

    public Date getCheckOutDate() {

       return checkOutDate;
    }

    public void setCheckOutDate(Date checkInDate) {
        this.checkOutDate = checkOutDate;
    }

    public boolean isRoomReserved(Date checkInDate, Date checkOutDate) {
        return false;
    }

    @Override
    public String toString() {
        return " Reservation: " + customer + " " + room + " CheckIn: " + checkInDate + " CheckOut: " + checkOutDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Reservation)) return false;
        Reservation reservation = (Reservation) o;
        return customer.equals( reservation.customer) && room.equals(reservation.room) && checkInDate.equals(reservation.checkInDate) && checkOutDate.equals(reservation.checkOutDate);
    }


    @Override
    public int hashCode() {

       return Objects.hash(customer, room, checkInDate, checkOutDate);
    }


}

// hashCode source:https://knowledge.udacity.com/questions/536745
//https://knowledge.udacity.com/questions/603669
