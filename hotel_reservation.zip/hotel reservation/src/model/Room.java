package model;

import java.util.Objects;

public class Room implements IRoom {

    protected String roomNumber;
    protected Double price;
    protected RoomType enumeration;

    public Room(String roomNumber, Double price, RoomType enumeration) {
        super();
        this.roomNumber = roomNumber;
        this.price = price;
        this.enumeration = enumeration;
    }

    public String getRoomNumber() {

        return roomNumber;
    }


    @Override
    public Double getRoomPrice() {

        return price;
    }


    public RoomType getRoomType() {

        return enumeration;
    }


    public boolean isFree() {

        return true;
    }

    @Override
    public String toString() {
        return "Room number: " + roomNumber + "Room price:" + price + " " + enumeration + price;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null )
            return false;
        if (getClass() != o.getClass())
            return false;
        Room room = (Room) o;
        return Objects.equals(roomNumber, room.roomNumber) && Objects.equals(price, room.price) && enumeration == room.enumeration;
    }

    @Override
    public int hashCode() {

        return Objects.hash(roomNumber, price, enumeration);
    }
}
// equals source: https://knowledge.udacity.com/questions/587574
// hashCode source:https://knowledge.udacity.com/questions/536745
