package service;

import model.Customer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class CustomerService {

    private static CustomerService customerService;
    private final Map<String,Customer> customers = new HashMap<>();

    public static CustomerService getCustomerService() {
        if (customerService == null) {
            customerService = new CustomerService();
        }
        return CustomerService.customerService;

        }


    public static void addCustomer(String email, String firstName, String LastName) {
        Customer customer = new Customer(firstName, LastName, email);

    }

    public static Customer getCustomer(String customerEmail){
        return (Customer) customerMap(customerEmail);

    }


    public static Collection<Customer> getAllCustomers() {
        String customerEmail = null;
        Collection<Customer> customers = customerMap(null);
        return customers;
    }



    private static Collection<Customer> customerMap(String customerEmail) {

        return null;
    }

}

//HashMap vs HashSet source:https://knowledge.udacity.com/questions/704967