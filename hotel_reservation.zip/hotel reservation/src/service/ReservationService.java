package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.*;

public class ReservationService {

    private static Map<String, IRoom> mapRoom;

    static {mapRoom = new HashMap<>();}

    private static final Map<String, Collection<Reservation>> mapReservation;

    static {mapReservation = new HashMap<>();}

    public static void addRoom(IRoom room) {mapRoom.put(room.getRoomNumber(), room);}
    public static IRoom getARoom(String roomId) {
        return mapRoom.get(roomId);
    }
    public static Reservation reserveRoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {

        if (isRoomReserved(room, checkInDate, checkOutDate)) {
            return null;
        }
        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        Collection<Reservation> customerReservations = getCustomerReservations(customer);
        if (customerReservations != null) {
        } else{
            customerReservations = new ArrayList<>();
        }
        final var add = customerReservations.add(reservation);
        mapReservation.put(customer.getEmail(), customerReservations);
        return reservation;
    }

    public static Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {
        Collection<IRoom> reservedRooms = getAllReservedRooms(checkInDate, checkOutDate);
        Collection<IRoom> listOfAvailableRooms = new ArrayList<>();
        for (IRoom room : getAllRooms()) {
            if (!reservedRooms.contains(room)) {
                listOfAvailableRooms.add(room);
            }
        }
        return listOfAvailableRooms;
    }

    public static Collection<Reservation> getCustomerReservations(Customer customer) {
        return mapReservation.get(customer.getEmail());
    }

    public static Collection<Reservation> getAllReservations() {
        Collection<Reservation> allReservations = new ArrayList<>();
        for (Collection<Reservation> customerReservations : mapReservation.values()) {
            allReservations.addAll(customerReservations);
        }
        return allReservations;
    }

    public static void setMapRoom(Map<String, IRoom> mapRoom) {
        ReservationService.mapRoom = mapRoom;
    }

    public static Collection<IRoom> getAllRooms() {
        return mapRoom.values();
    }

    public static Collection<IRoom> getAllReservedRooms(Date checkInDate, Date checkOutDate) {
        Collection<IRoom> reservedRooms = new ArrayList<>();
        for (Reservation reservation : getAllReservations()) {
            if (reservation.isRoomReserved(checkInDate, checkOutDate)) {
                reservedRooms.add(reservation.getRoom());
            }
        }
        return reservedRooms;
    }

    private static boolean isRoomReserved(IRoom room, Date checkInDate, Date checkOutDate) {
        Collection<IRoom> reservedRooms = getAllReservedRooms(checkInDate, checkOutDate);
        return reservedRooms.contains(room);
    }

    public static IRoom getRoom(String roomNumber) {
        return null;
    }
}

//https://knowledge.udacity.com/questions/536745